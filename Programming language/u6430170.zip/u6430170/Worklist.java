package u6430170;

public interface Worklist<T>  {
    void add(T item);
    boolean hasMore();
    T remove();
}